function LoadingPage() {
    return (
      <section className="section loading-page">
        
        <div className="loading-page-logo"></div>
      </section>
    );
  }
  
  export default LoadingPage;